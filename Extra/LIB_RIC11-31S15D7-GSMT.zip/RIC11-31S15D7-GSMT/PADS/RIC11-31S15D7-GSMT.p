*PADS-LIBRARY-PART-TYPES-V9*

RIC11-31S15D7-GSMT RIC1131S15D7GSMT I ANA 7 1 0 0 0
TIMESTAMP 2025.08.28.07.23.35
"Mouser Part Number" 179-RIC1131S15D7GSMT
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Same-Sky/RIC11-31S15D7-GSMT?qs=HoCaDK9Nz5f2ZKwRf%252BFYTA%3D%3D
"Manufacturer_Name" Same Sky
"Manufacturer_Part_Number" RIC11-31S15D7-GSMT
"Description" 12 mm, 5 Vdc, 15 PPR, Surface Mount, Mechanical Panel Mount Encoder , 5V ,
"Datasheet Link" https://www.sameskydevices.com/product/resource/ric11.pdf
"Geometry.Height" 19.8mm
GATE 1 7 0
RIC11-31S15D7-GSMT
1 0 U MP1
2 0 U MP2
A1 0 U NO1
B1 0 U NO2
C1 0 U COM
D1 0 U D1
E1 0 U E1

*END*
*REMARK* SamacSys ECAD Model
18922120/1627512/2.50/7/2/Undefined or Miscellaneous
